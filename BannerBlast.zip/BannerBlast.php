    <?php
    /**
     * Plugin Name: Announcement Banner
     * Description: A plugin to add customizable announcement banners on your WordPress site.
     * Version: 1.1
     * Author: Your Name
     */

    // Exit if accessed directly.
    if ( ! defined( 'ABSPATH' ) ) {
        exit;
    }

    class AnnouncementBannerPlugin {

        public function __construct() {
            // Hook to add admin menu
            add_action( 'admin_menu', [ $this, 'add_admin_menu' ] );

            // Hook to enqueue scripts and styles
            add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_scripts' ] );

            // Hook to display banner
            add_action( 'wp_footer', [ $this, 'display_banner' ] );

            // Register settings
            add_action( 'admin_init', [ $this, 'register_settings' ] );

            // Generate CSS dynamically
            add_action( 'init', [ $this, 'generate_styles' ] );
        }

        public function add_admin_menu() {
            add_menu_page(
                'Announcement Banner',
                'Banner Settings',
                'manage_options',
                'announcement-banner-settings',
                [ $this, 'create_admin_page' ],
                'dashicons-megaphone',
                100
            );
        }

        public function enqueue_scripts() {
            wp_enqueue_style( 'announcement-banner-style', plugin_dir_url( __FILE__ ) . 'css/style.css' );
        }

        public function register_settings() {
            register_setting( 'announcement_banner_settings', 'announcement_banner_text' );
            register_setting( 'announcement_banner_settings', 'announcement_banner_link' );
            register_setting( 'announcement_banner_settings', 'announcement_banner_width' );
            register_setting( 'announcement_banner_settings', 'announcement_banner_height' );
            register_setting( 'announcement_banner_settings', 'announcement_banner_font_style' );
            register_setting( 'announcement_banner_settings', 'announcement_banner_font_color' );
            register_setting( 'announcement_banner_settings', 'announcement_banner_font_size' );
            register_setting( 'announcement_banner_settings', 'announcement_banner_background_color' );
            register_setting( 'announcement_banner_settings', 'announcement_banner_marquee' );
        }

        public function create_admin_page() {
            ?>
            <div class="wrap">
                <h1>Announcement Banner Settings</h1>
                <form method="post" action="options.php">
                    <?php settings_fields( 'announcement_banner_settings' ); ?>
                    <?php do_settings_sections( 'announcement_banner_settings' ); ?>

                    <table class="form-table">
                        <tr valign="top">
                            <th scope="row">Banner Text</th>
                            <td>
                                <input type="text" name="announcement_banner_text" value="<?php echo esc_attr( get_option( 'announcement_banner_text', '' ) ); ?>" style="width: 100%;">
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row">Button Link</th>
                            <td>
                                <input type="url" name="announcement_banner_link" value="<?php echo esc_attr( get_option( 'announcement_banner_link', '' ) ); ?>" style="width: 100%;">
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row">Banner Width</th>
                            <td>
                                <input type="text" name="announcement_banner_width" value="<?php echo esc_attr( get_option( 'announcement_banner_width', '100%' ) ); ?>">
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row">Banner Height</th>
                            <td>
                                <input type="text" name="announcement_banner_height" value="<?php echo esc_attr( get_option( 'announcement_banner_height', 'auto' ) ); ?>">
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row">Font Style</th>
                            <td>
                                <input type="text" name="announcement_banner_font_style" value="<?php echo esc_attr( get_option( 'announcement_banner_font_style', 'normal' ) ); ?>">
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row">Font Color</th>
                            <td>
                                <input type="color" name="announcement_banner_font_color" value="<?php echo esc_attr( get_option( 'announcement_banner_font_color', '#ffffff' ) ); ?>">
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row">Font Size</th>
                            <td>
                                <input type="text" name="announcement_banner_font_size" value="<?php echo esc_attr( get_option( 'announcement_banner_font_size', '16px' ) ); ?>">
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row">Background Color</th>
                            <td>
                                <input type="color" name="announcement_banner_background_color" value="<?php echo esc_attr( get_option( 'announcement_banner_background_color', '#333333' ) ); ?>">
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row">Enable Marquee</th>
                            <td>
                                <input type="checkbox" name="announcement_banner_marquee" value="1" <?php checked( get_option( 'announcement_banner_marquee', 0 ) ); ?>>
                            </td>
                        </tr>
                    </table>

                    <?php submit_button(); ?>
                </form>
            </div>
            <?php
        }

        public function display_banner() {
            $text = get_option( 'announcement_banner_text', '' );
            $link = get_option( 'announcement_banner_link', '#' );
            $marquee = get_option( 'announcement_banner_marquee', 0 );

            if ( ! empty( $text ) ) {
                $content = '<div class="announcement-banner">';

                if ( $marquee ) {
                    $content .= '<marquee><div class="banner-content">' . esc_html( $text ) . '</div></marquee>';
                } else {
                    $content .= '<div class="banner-content">' . esc_html( $text ) . '</div>';
                }

                $content .= '<a href="' . esc_url( $link ) . '" class="banner-button">Learn More</a>';
                $content .= '</div>';

                echo $content;
            }
        }

        public function generate_styles() {
            $width = esc_attr( get_option( 'announcement_banner_width', '100%' ) );
            $height = esc_attr( get_option( 'announcement_banner_height', 'auto' ) );
            $font_style = esc_attr( get_option( 'announcement_banner_font_style', 'normal' ) );
            $font_color = esc_attr( get_option( 'announcement_banner_font_color', '#ffffff' ) );
            $font_size = esc_attr( get_option( 'announcement_banner_font_size', '16px' ) );
            $background_color = esc_attr( get_option( 'announcement_banner_background_color', '#333333' ) );

            $style_content = "
            .announcement-banner {
                position: fixed;
                bottom: 0;
                width: $width;
                height: $height;
                background: $background_color;
                color: $font_color;
                font-style: $font_style;
                font-size: $font_size;
                text-align: center;
                padding: 10px 20px;
                z-index: 9999;
            }
            .announcement-banner .banner-content {
                display: flex;
                justify-content: center;
                align-items: center;
            }
            .announcement-banner .banner-button {
                background: #0073aa;
                color: #fff;
                padding: 5px 15px;
                text-decoration: none;
                margin-left: 10px;
                border-radius: 5px;
            }
            .announcement-banner .banner-button:hover {
                background: #005177;
            }
            ";

            file_put_contents( plugin_dir_path( __FILE__ ) . 'css/style.css', $style_content );
        }
    }

    new AnnouncementBannerPlugin();
